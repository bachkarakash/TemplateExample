package com.template.example;

public class Map<T1, T2> {

}
