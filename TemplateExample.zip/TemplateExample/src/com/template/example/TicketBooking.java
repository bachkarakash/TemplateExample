package com.template.example;

public abstract class TicketBooking 
{
	abstract void preBooking();
	abstract void bookTicket();
	abstract void postBooking();
	public final void manageBooking()
	{
		preBooking();
		bookTicket();
		postBooking();
	}

}
