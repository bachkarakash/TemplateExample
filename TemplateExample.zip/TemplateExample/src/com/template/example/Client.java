package com.template.example;

import java.util.Scanner;

public class Client 
{
	public static void main(String[] args)
	{
		TicketBooking ticketBooking;
		Scanner sc = new Scanner(System.in);
		int choice;
		System.out.println("1) Book Flight\n2) Book Train\n3) Book Bus\n");
		choice = sc.nextInt();
		switch(choice)
		{
		case 1:
			ticketBooking = new FlightTicketBooking();
			ticketBooking.manageBooking();
			break;
		case 2:
			ticketBooking = new TrainTicketBooking();
			ticketBooking.manageBooking();
			break;
		case 3:
			ticketBooking = new BusTicketBooking();
			ticketBooking.manageBooking();
			break;
		default:
			break;
		}
	}

}
