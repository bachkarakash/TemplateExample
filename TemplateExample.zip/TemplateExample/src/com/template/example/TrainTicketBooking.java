package com.template.example;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class TrainTicketBooking extends TicketBooking
{
	private static final Exception Exception = null;
	HashMap<String, InnerMap> flights = new HashMap<String, InnerMap>();
	public TrainTicketBooking()
	{
		InnerMap innerMap = new InnerMap();
		innerMap.setKeyVal("Pune",5);
		flights.put("Mumbai", innerMap);
		InnerMap innerMap1 = new InnerMap();
		innerMap1.setKeyVal("Bangalore",10);
		flights.put("Mumbai", innerMap);
		InnerMap innerMap3 = new InnerMap();
		innerMap3.setKeyVal("Mumbai",8);
		flights.put("Bangalore", innerMap);
		InnerMap innerMap4 = new InnerMap();
		innerMap4.setKeyVal("Bangalore",4);
		flights.put("Pune", innerMap);
	}
	public TrainTicketBooking getTrainTicketObject() {
		return new TrainTicketBooking();
	}
	public boolean isValidAadhar(String aadharNumber)
	{
		if(aadharNumber.length()==12)
			return true;
		return false;
	}
	public void webCheckIn()
	{
		System.out.println("WebCheckIn Successful!!");
	}
	public boolean isTicketAvailable(String source,String destination,Integer tickets)
	{
		Iterator it = flights.entrySet().iterator();	
		while(it.hasNext())
		{
			Map.Entry m = (Map.Entry)it.next();
			String src = (String)m.getKey();
			InnerMap dest = (InnerMap)m.getValue();
			if(src.equalsIgnoreCase(source) && dest.key.equalsIgnoreCase(destination) && dest.val>=tickets)
			{
				return true;
			}
		}
		return false;
	}

	@Override
	void preBooking() {
		// TODO Auto-generated method stub
		String aadharNumber;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Aadhar Number: ");
		aadharNumber = sc.next();
		
		if(this.isValidAadhar(aadharNumber))
		{
			System.out.println("You can book the ticket");
		} else
			try {
				throw Exception;
			} catch (java.lang.Exception e) {
				// TODO Auto-generated catch block
				System.out.println("You cannot book the ticket");
				System.exit(0);
			}
	}

	@Override
	void bookTicket() {
		// TODO Auto-generated method stub
		String source,destination;
		Integer tickets;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter source: ");
		source = sc.next();
		System.out.println("Enter destination: ");
		destination = sc.next();
		System.out.println("Enter number of tickets: ");
		tickets = sc.nextInt();
		if(this.isTicketAvailable(source, destination,tickets))
		{
			System.out.println("Your Ticket has been booked");
		}
		else
			try {
				throw Exception;
			} catch (java.lang.Exception e) {
				// TODO Auto-generated catch block
				System.out.println("Tickets Unavailable");
				System.exit(0);
			}
	}

	@Override
	void postBooking() {
		// TODO Auto-generated method stub
		this.webCheckIn();
	}

}
