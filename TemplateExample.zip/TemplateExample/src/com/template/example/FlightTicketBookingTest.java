package com.template.example;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FlightTicketBookingTest {

	FlightTicketBooking flightTicketObject=null;
	@BeforeEach
	public void setUp() throws Exception
	{
		flightTicketObject = new FlightTicketBooking();
	}
	@Test
	void testTicketAvailable() 
	{
		assertTrue(flightTicketObject.isTicketAvailable("mumbai", "pune", 2));
	}
	
	@Test
	void testTicketNotAvailable()
	{
		assertFalse(flightTicketObject.isTicketAvailable("mumbai", "pune", 10));
	}

}
